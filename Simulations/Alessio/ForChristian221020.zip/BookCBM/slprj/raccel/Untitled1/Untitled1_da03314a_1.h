#ifndef __Untitled1_da03314a_1_h__
#define __Untitled1_da03314a_1_h__
#ifdef __cplusplus
extern "C" {
#endif
extern void Untitled1_da03314a_1_dae ( NeDae * * dae , const
NeModelParameters * modelParams , const NeSolverParameters * solverParams ) ;
#ifdef __cplusplus
}
#endif
#endif
