#ifndef RTW_HEADER_Untitled1_capi_h_
#define RTW_HEADER_Untitled1_capi_h_
#include "Untitled1.h"
extern void Untitled1_InitializeDataMapInfo ( void ) ;
#endif
