#ifndef __Untitled1_da03314a_1_gateway_h__
#define __Untitled1_da03314a_1_gateway_h__
#ifdef __cplusplus
extern "C" {
#endif
extern void Untitled1_da03314a_1_gateway ( void ) ;
#ifdef __cplusplus
}
#endif
#endif
